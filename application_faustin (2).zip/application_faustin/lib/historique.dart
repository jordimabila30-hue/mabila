import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final supabase = Supabase.instance.client;

/// =========================
/// MODÈLES DE DONNÉES
/// =========================
class DataPoint {
  final double time;
  final double value;
  DataPoint(this.time, this.value);
}

class AnomalyPoint {
  final double time;
  final double value;
  final String description;

  AnomalyPoint(this.time, this.value, this.description);
}

class StatsWindow {
  final int size;
  final List<double> values = [];

  StatsWindow(this.size);

  void add(double v) {
    values.add(v);
    if (values.length > size) values.removeAt(0);
  }

  double mean() =>
      values.isEmpty ? 0 : values.reduce((a, b) => a + b) / values.length;

  double std() {
    if (values.length < 2) return 0;
    final m = mean();
    final variance =
        values.map((e) => math.pow(e - m, 2)).reduce((a, b) => a + b) /
        values.length;
    return math.sqrt(variance);
  }
}

/// =========================
/// PAGE HISTORIQUE
/// =========================
class HistoricalPage extends StatefulWidget {
  const HistoricalPage({super.key});

  @override
  State<HistoricalPage> createState() => _HistoricalPageState();
}

class _HistoricalPageState extends State<HistoricalPage> {
  List<File> csvFiles = [];

  @override
  void initState() {
    super.initState();
    _loadFiles();
  }

  Future<void> _loadFiles() async {
    final dir = await getApplicationDocumentsDirectory();
    final files = dir.listSync();
    final csv = files
        .whereType<File>()
        .where((f) => f.path.endsWith('.csv'))
        .toList();
    csv.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
    setState(() => csvFiles = csv);
  }

  Future<void> uploadCsv(File file) async {
    try {
      final fileName = file.path.split(Platform.pathSeparator).last;
      await supabase.storage.from('missions').upload(fileName, file);
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Fichier $fileName envoyé !')));
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Erreur upload : $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Historique des missions')),
      body: csvFiles.isEmpty
          ? const Center(child: Text("Aucun fichier trouvé"))
          : ListView.builder(
              itemCount: csvFiles.length,
              itemBuilder: (_, i) {
                final file = csvFiles[i];
                final name = file.path.split(Platform.pathSeparator).last;
                return ListTile(
                  leading: const Icon(Icons.description, color: Colors.green),
                  title: Text(name),
                  trailing: IconButton(
                    icon: const Icon(Icons.cloud_upload),
                    onPressed: () => uploadCsv(file),
                  ),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ChartNavigationPage(file: file),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

/// =========================
/// PAGE GRAPHIQUES (AVEC ANOMALIES)
/// =========================
class ChartNavigationPage extends StatefulWidget {
  final File file;
  const ChartNavigationPage({super.key, required this.file});

  @override
  State<ChartNavigationPage> createState() => _ChartNavigationPageState();
}

class _ChartNavigationPageState extends State<ChartNavigationPage> {
  // Données
  List<DataPoint> altitude = [],
      speed = [],
      acc = [],
      roll = [],
      pitch = [],
      yaw = [],
      pressure = [],
      temp = [];
  List<DataPoint> altF = [],
      speedF = [],
      accF = [],
      rollF = [],
      pitchF = [],
      yawF = [],
      pressF = [],
      tempF = [];

  Map<String, List<AnomalyPoint>> anomalies = {};
  final Map<String, StatsWindow> _stats = {
    "altitude": StatsWindow(20),
    "vitesse": StatsWindow(20),
    "accélération": StatsWindow(20),
    "pression": StatsWindow(20),
    "température": StatsWindow(20),
  };

  final TextEditingController _rangeController = TextEditingController();
  String? _filterError; // Corrigé : ré-ajouté ici
  bool isLoading = true;
  int _currentIndex = 0;
  late ZoomPanBehavior _zoomBehavior;

  final List<String> _titles = [
    "Altitude",
    "Vitesse",
    "Accélération",
    "Orientation",
    "Pression",
    "Température",
  ];

  @override
  void initState() {
    super.initState();
    _zoomBehavior = ZoomPanBehavior(
      enablePinching: true,
      enablePanning: true,
      enableDoubleTapZooming: true,
    );
    _loadCsv();
  }

  void _detectAnomalies(List<DataPoint> data, String key) {
    final list = <AnomalyPoint>[];
    final stats = _stats[key.toLowerCase()];
    if (stats == null) return;
    stats.values.clear();

    for (final p in data) {
      stats.add(p.value);
      final mean = stats.mean();
      final std = stats.std();
      if (std == 0) continue;

      if ((p.value - mean).abs() > 3.5 * std) {
        String desc = p.value > mean ? "Pic anormal" : "Chute anormale";
        if (key.toLowerCase() == "température" && p.value > 45)
          desc = "Surchauffe !";
        list.add(AnomalyPoint(p.time, p.value, desc));
      }
    }
    anomalies[key.toLowerCase()] = list;
  }

  Future<void> _loadCsv() async {
    try {
      final lines = await widget.file.readAsLines();
      for (int i = 1; i < lines.length; i++) {
        final parts = lines[i].split(';');
        if (parts.length < 9) continue;
        final t = double.tryParse(parts[0]) ?? 0;
        altitude.add(DataPoint(t, double.tryParse(parts[1]) ?? 0));
        speed.add(DataPoint(t, double.tryParse(parts[2]) ?? 0));
        acc.add(DataPoint(t, double.tryParse(parts[3]) ?? 0));
        roll.add(DataPoint(t, double.tryParse(parts[4]) ?? 0));
        pitch.add(DataPoint(t, double.tryParse(parts[5]) ?? 0));
        yaw.add(DataPoint(t, double.tryParse(parts[6]) ?? 0));
        pressure.add(DataPoint(t, double.tryParse(parts[7]) ?? 0));
        temp.add(DataPoint(t, double.tryParse(parts[8]) ?? 0));
      }
      _resetFilters();
      for (var title in _titles) {
        _detectAnomalies(_getListForTitle(title, original: true), title);
      }
    } catch (e) {
      debugPrint("Erreur CSV: $e");
    }
    setState(() => isLoading = false);
  }

  List<DataPoint> _getListForTitle(String title, {required bool original}) {
    if (original) {
      switch (title) {
        case "Altitude":
          return altitude;
        case "Vitesse":
          return speed;
        case "Accélération":
          return acc;
        case "Pression":
          return pressure;
        case "Température":
          return temp;
        default:
          return [];
      }
    } else {
      switch (title) {
        case "Altitude":
          return altF;
        case "Vitesse":
          return speedF;
        case "Accélération":
          return accF;
        case "Pression":
          return pressF;
        case "Température":
          return tempF;
        default:
          return [];
      }
    }
  }

  void _resetFilters() {
    setState(() {
      altF = List.from(altitude);
      speedF = List.from(speed);
      accF = List.from(acc);
      rollF = List.from(roll);
      pitchF = List.from(pitch);
      yawF = List.from(yaw);
      pressF = List.from(pressure);
      tempF = List.from(temp);
      _filterError = null;
    });
  }

  void _applyFilter() {
    try {
      final parts = _rangeController.text.split('-');
      if (parts.length != 2) throw Exception("Format mm:ss-mm:ss");

      double toSec(String s) {
        final p = s.trim().split(':');
        return (int.parse(p[0]) * 60) + double.parse(p[1]);
      }

      final start = toSec(parts[0]);
      final end = toSec(parts[1]);

      setState(() {
        altF = altitude.where((p) => p.time >= start && p.time <= end).toList();
        speedF = speed.where((p) => p.time >= start && p.time <= end).toList();
        accF = acc.where((p) => p.time >= start && p.time <= end).toList();
        pressF = pressure
            .where((p) => p.time >= start && p.time <= end)
            .toList();
        tempF = temp.where((p) => p.time >= start && p.time <= end).toList();
        _filterError = null;
      });
    } catch (e) {
      setState(() => _filterError = "Erreur format (ex: 0:10-1:00)");
    }
  }

  Widget _buildChart(List<DataPoint> data, String title, Color color) {
    if (data.isEmpty)
      return const Center(child: Text("Aucune donnée sur cette plage"));

    return SfCartesianChart(
      zoomPanBehavior: _zoomBehavior,
      trackballBehavior: TrackballBehavior(
        enable: true,
        activationMode: ActivationMode.singleTap,
        builder: (context, details) {
          final point = details.point!;
          final time = point.x.toInt();
          final m = (time ~/ 60).toString().padLeft(2, '0');
          final s = (time % 60).toString().padLeft(2, '0');

          final anomaly = (anomalies[title.toLowerCase()] ?? []).firstWhere(
            (a) => (a.time - point.x).abs() < 0.1,
            orElse: () => AnomalyPoint(0, 0, ""),
          );

          return Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: anomaly.description.isNotEmpty
                  ? Colors.red
                  : Colors.black87,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "t = $m:$s",
                  style: const TextStyle(color: Colors.white70, fontSize: 10),
                ),
                Text(
                  "$title: ${point.y?.toStringAsFixed(2)}",
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                if (anomaly.description.isNotEmpty)
                  Text(
                    anomaly.description,
                    style: const TextStyle(
                      color: Colors.yellow,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
              ],
            ),
          );
        },
      ),
      series: [
        SplineSeries<DataPoint, double>(
          dataSource: data,
          xValueMapper: (d, _) => d.time,
          yValueMapper: (d, _) => d.value,
          color: color,
          width: 3,
          animationDuration: 0,
        ),
        ScatterSeries<AnomalyPoint, double>(
          dataSource: anomalies[title.toLowerCase()] ?? [],
          xValueMapper: (a, _) => a.time,
          yValueMapper: (a, _) => a.value,
          color: Colors.red,
          markerSettings: const MarkerSettings(
            isVisible: true,
            height: 10,
            width: 10,
            shape: DataMarkerType.circle,
          ),
        ),
      ],
      primaryXAxis: NumericAxis(
        axisLabelFormatter: (details) {
          final sec = details.value!.toInt();
          return ChartAxisLabel(
            "${(sec ~/ 60).toString().padLeft(2, '0')}:${(sec % 60).toString().padLeft(2, '0')}",
            const TextStyle(color: Colors.white70),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final name = widget.file.path.split(Platform.pathSeparator).last;

    return Scaffold(
      appBar: AppBar(title: Text(name)),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _rangeController,
                              decoration: const InputDecoration(
                                hintText: "0:00-1:30",
                                labelText: "Filtrer mm:ss-mm:ss",
                              ),
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.check, color: Colors.cyan),
                            onPressed: _applyFilter,
                          ),
                          IconButton(
                            icon: const Icon(Icons.refresh),
                            onPressed: () {
                              _rangeController.clear();
                              _resetFilters();
                            },
                          ),
                        ],
                      ),
                      if (_filterError != null)
                        Text(
                          _filterError!,
                          style: const TextStyle(
                            color: Colors.red,
                            fontSize: 12,
                          ),
                        ),
                    ],
                  ),
                ),
                Expanded(
                  child: _buildChart(
                    _getListForTitle(_titles[_currentIndex], original: false),
                    _titles[_currentIndex],
                    Colors.cyan,
                  ),
                ),
              ],
            ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (i) => setState(() => _currentIndex = i),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.cyan,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.height), label: "Alt"),
          BottomNavigationBarItem(icon: Icon(Icons.speed), label: "Vit"),
          BottomNavigationBarItem(icon: Icon(Icons.bolt), label: "Acc"),
          BottomNavigationBarItem(
            icon: Icon(Icons.screen_rotation),
            label: "Ori",
          ),
          BottomNavigationBarItem(icon: Icon(Icons.compress), label: "Pres"),
          BottomNavigationBarItem(icon: Icon(Icons.thermostat), label: "Temp"),
        ],
      ),
    );
  }
}
