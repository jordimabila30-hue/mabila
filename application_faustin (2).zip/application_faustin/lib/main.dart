import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'historique.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:csv/csv.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  await Supabase.initialize(
    url: 'https://pumixubpuwvwacpugdhm.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB1bWl4dWJwdXd2d2FjcHVnZGhtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzUyNzgwMzMsImV4cCI6MjA5MDg1NDAzM30.RasDC9nhsL3jfskjAYSZU_5Q2UORb755q6VYnmcKqvc',
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color.fromARGB(255, 48, 50, 48),
          brightness: Brightness.dark,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class DataPoint {
  final double time;
  final double value;
  DataPoint(this.time, this.value);
}

class CircularDataBuffer {
  final List<DataPoint> buffer;
  final int maxPoints;
  final double windowSize;
  double? _lastTime;

  CircularDataBuffer({int maxPoints = 300, double windowSize = 15.0})
    : buffer = [],
      maxPoints = maxPoints,
      windowSize = windowSize;

  void addPoint(double time, double value) {
    final point = DataPoint(time, value);
    buffer.add(point);
    _lastTime = time;

    while (buffer.isNotEmpty && buffer.first.time < time - windowSize) {
      buffer.removeAt(0);
    }
    if (buffer.length > maxPoints) {
      buffer.removeRange(0, buffer.length - maxPoints);
    }
  }

  List<DataPoint> get visibleData {
    if (buffer.isEmpty || _lastTime == null) return buffer;
    return buffer.where((p) => p.time >= (_lastTime! - windowSize)).toList();
  }

  bool get hasData => buffer.isNotEmpty;
  double get maxTime => _lastTime ?? 0;
}

enum DashboardMetric { altitude, speed, acceleration, orientation, environment }

extension DashboardMetricX on DashboardMetric {
  String get label {
    switch (this) {
      case DashboardMetric.altitude:
        return 'Altitude';
      case DashboardMetric.speed:
        return 'Vitesse';
      case DashboardMetric.acceleration:
        return 'Accélération';
      case DashboardMetric.orientation:
        return 'Orientation';
      case DashboardMetric.environment:
        return 'Environnement';
    }
  }

  IconData get icon {
    switch (this) {
      case DashboardMetric.altitude:
        return Icons.terrain;
      case DashboardMetric.speed:
        return Icons.speed;
      case DashboardMetric.acceleration:
        return Icons.bolt;
      case DashboardMetric.orientation:
        return Icons.explore;
      case DashboardMetric.environment:
        return Icons.thermostat;
    }
  }

  Color get color {
    switch (this) {
      case DashboardMetric.altitude:
        return Colors.cyanAccent;
      case DashboardMetric.speed:
        return Colors.orangeAccent;
      case DashboardMetric.acceleration:
        return Colors.purpleAccent;
      case DashboardMetric.orientation:
        return Colors.lightGreenAccent;
      case DashboardMetric.environment:
        return Colors.amberAccent;
    }
  }
}

class DashboardTile extends StatelessWidget {
  final String label;
  final double value;
  final IconData icon;
  final Color color;

  const DashboardTile({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: const Color(0xFF111827).withOpacity(0.94),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.8), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(width: 10),
          Text(
            value.toStringAsFixed(2),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

class MissionTimeBox extends StatelessWidget {
  final Duration elapsed;
  final Duration estimatedTotal;

  const MissionTimeBox({
    super.key,
    required this.elapsed,
    required this.estimatedTotal,
  });

  String _format(Duration d) {
    final h = d.inHours.toString().padLeft(2, '0');
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final remaining = estimatedTotal - elapsed;
    final remainingSafe = remaining.isNegative ? Duration.zero : remaining;

    return Container(
      width: 265,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A).withOpacity(0.90),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.28),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          const Icon(Icons.timer, color: Colors.white70, size: 24),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Durée de mission',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Écoulé : ${_format(elapsed)}',
                  style: const TextStyle(
                    color: Colors.cyan,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Estimé total : ${_format(estimatedTotal)}',
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
                const SizedBox(height: 4),
                Text(
                  'Restant approx. : ${_format(remainingSafe)}',
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  bool isDark = true;

  int missionCount = 0;
  int csvFilesCount = 0;

  void toggleTheme() {
    setState(() {
      isDark = !isDark;
    });
  }

  late TabController _tabController;
  late AnimationController _animationController;
  String? currentMissionId;
  bool _userStopped = false;
  File? csvFile;
  bool csvHeaderWritten = false;
  String? csvFilePath;
  int missionCounter = 0;

  WebSocketChannel? channel;
  Timer? _retryTimer;
  bool isConnected = false;
  int _retryCount = 0;
  static const int maxRetries = 5;
  double? startTime;
  DateTime? lastThingSpeakSend;

  Timer? _missionTimer;
  Duration _elapsedMission = Duration.zero;
  Duration _estimatedMissionTotal = const Duration(minutes: 10);

  late final CircularDataBuffer altitudeBuffer;
  late final CircularDataBuffer speedBuffer;
  late final CircularDataBuffer verticalAccBuffer;
  late final CircularDataBuffer rollBuffer;
  late final CircularDataBuffer pitchBuffer;
  late final CircularDataBuffer yawBuffer;
  late final CircularDataBuffer pressureBuffer;
  late final CircularDataBuffer temperatureBuffer;

  static const double windowSize = 9;

  final List<DashboardMetric> _selectedMetrics = [
    DashboardMetric.speed,
    DashboardMetric.altitude,
    DashboardMetric.acceleration,
    DashboardMetric.orientation,
  ];

  Future<void> _initCsvFile({String? customDirectory}) async {
    Directory directory;

    if (customDirectory != null) {
      directory = Directory(customDirectory);
      if (!directory.existsSync()) {
        await directory.create(recursive: true);
      }
    } else {
      directory = await getApplicationDocumentsDirectory();
    }

    csvFilesCount++;
    missionCounter++;
    await _saveCounters();

    final now = DateTime.now();
    final formattedDate =
        "${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}";
    final formattedTime =
        "${now.hour.toString().padLeft(2, '0')}-${now.minute.toString().padLeft(2, '0')}";

    final fileName =
        "mission_${missionCounter}_${formattedDate}_$formattedTime.csv";
    final path = '${directory.path}/$fileName';

    csvFile = File(path);
    await csvFile!.create();

    csvHeaderWritten = false;
    csvFilePath = path;

    debugPrint(' Fichier CSV créé: $path');
  }

  Future<void> _writeDataToCsv(
    Map<String, dynamic> data,
    double localTime,
  ) async {
    if (csvFile == null) return;

    if (!csvHeaderWritten) {
      final header = [
        'time',
        'altitude',
        'speed',
        'vertical_acc',
        'roll',
        'pitch',
        'yaw',
        'pressure',
        'temperature',
      ];
      final csvHeader = const ListToCsvConverter(
        fieldDelimiter: ';',
      ).convert([header]);
      await csvFile!.writeAsString('$csvHeader\n', mode: FileMode.write);
      csvHeaderWritten = true;
    }

    final row = [
      localTime.toStringAsFixed(2),
      (data['altitude'] ?? 0).toString(),
      (data['speed'] ?? 0).toString(),
      (data['vertical_acc'] ?? 0).toString(),
      (data['roll'] ?? 0).toString(),
      (data['pitch'] ?? 0).toString(),
      (data['yaw'] ?? 0).toString(),
      (data['pressure'] ?? 0).toString(),
      (data['temperature'] ?? 0).toString(),
    ];

    final csvRow = const ListToCsvConverter(fieldDelimiter: ';').convert([row]);
    await csvFile!.writeAsString('$csvRow\n', mode: FileMode.append);
  }

  Future<void> endMission() async {
    _userStopped = true;
    _missionTimer?.cancel();
    channel?.sink.close();
    channel = null;
    if (mounted) setState(() => isConnected = false);
  }

  void _resetForNewMission() {
    altitudeBuffer.buffer.clear();
    speedBuffer.buffer.clear();
    verticalAccBuffer.buffer.clear();
    rollBuffer.buffer.clear();
    pitchBuffer.buffer.clear();
    yawBuffer.buffer.clear();
    pressureBuffer.buffer.clear();
    temperatureBuffer.buffer.clear();

    startTime = null;
    _elapsedMission = Duration.zero;
    _estimatedMissionTotal = const Duration(minutes: 10);

    _missionTimer?.cancel();
    _missionTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (startTime == null) return;
      setState(() {
        _elapsedMission = DateTime.now().difference(
          DateTime.fromMillisecondsSinceEpoch((startTime! * 1000).toInt()),
        );

        if (_estimatedMissionTotal < const Duration(minutes: 3)) {
          _estimatedMissionTotal = const Duration(minutes: 3);
        }
      });
    });

    channel?.sink.close();
    channel = null;

    _initCsvFile();
    _connectWebSocket();
  }

  @override
  void initState() {
    super.initState();
    _loadCounters();
    _tabController = TabController(length: 5, vsync: this);
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 16),
      vsync: this,
    );

    altitudeBuffer = CircularDataBuffer();
    speedBuffer = CircularDataBuffer();
    verticalAccBuffer = CircularDataBuffer();
    rollBuffer = CircularDataBuffer();
    pitchBuffer = CircularDataBuffer();
    yawBuffer = CircularDataBuffer();
    pressureBuffer = CircularDataBuffer();
    temperatureBuffer = CircularDataBuffer();

    _initCsvFile().then((_) {
      _connectWebSocket();
    });
    _startSmoothAnimation();
  }

  Future<void> _loadCounters() async {
    final prefs = await SharedPreferences.getInstance();
    missionCount = prefs.getInt('missionCount') ?? 0;
    csvFilesCount = prefs.getInt('csvFilesCount') ?? 0;
    setState(() {});
  }

  Future<void> _saveCounters() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('missionCount', missionCount);
    await prefs.setInt('csvFilesCount', csvFilesCount);
    setState(() {});
  }

  void _startSmoothAnimation() {
    _animationController.forward();
  }

  void _connectWebSocket() async {
    _userStopped = false;
    try {
      channel?.sink.close();
      channel = WebSocketChannel.connect(Uri.parse('ws://127.0.0.1:8765'));

      if (mounted) setState(() => isConnected = true);
      _retryCount = 0;
      _retryTimer?.cancel();

      channel!.stream.listen(
        (message) {
          try {
            final data = jsonDecode(message) as Map<String, dynamic>;
            final now = DateTime.now().millisecondsSinceEpoch / 1000;

            startTime ??= now;
            final localTime = now - startTime!;

            _addPointToBuffer(
              altitudeBuffer,
              localTime,
              (data['altitude'] ?? 0).toDouble(),
            );
            _addPointToBuffer(
              speedBuffer,
              localTime,
              (data['speed'] ?? 0).toDouble(),
            );
            _addPointToBuffer(
              verticalAccBuffer,
              localTime,
              (data['vertical_acc'] ?? 0).toDouble(),
            );
            _addPointToBuffer(
              rollBuffer,
              localTime,
              (data['roll'] ?? 0).toDouble(),
            );
            _addPointToBuffer(
              pitchBuffer,
              localTime,
              (data['pitch'] ?? 0).toDouble(),
            );
            _addPointToBuffer(
              yawBuffer,
              localTime,
              (data['yaw'] ?? 0).toDouble(),
            );
            _addPointToBuffer(
              pressureBuffer,
              localTime,
              (data['pressure'] ?? 0).toDouble(),
            );
            _addPointToBuffer(
              temperatureBuffer,
              localTime,
              (data['temperature'] ?? 0).toDouble(),
            );

            _writeDataToCsv(data, localTime);

            if (mounted) {
              final currentElapsed = DateTime.now().difference(
                DateTime.fromMillisecondsSinceEpoch(
                  (startTime! * 1000).toInt(),
                ),
              );
              setState(() {
                _elapsedMission = currentElapsed;
              });
            }
          } catch (e) {
            debugPrint('JSON parse error: $e');
          }
        },
        onError: (error) {
          debugPrint('WS Error: $error');
          if (mounted) setState(() => isConnected = false);
          _scheduleRetry();
        },
        onDone: () {
          debugPrint('WS Closed');
          if (mounted) setState(() => isConnected = false);
          _scheduleRetry();
        },
      );
    } catch (e) {
      debugPrint('Connection failed: $e');
      if (mounted) setState(() => isConnected = false);
      _scheduleRetry();
    }
  }

  void _addPointToBuffer(CircularDataBuffer buffer, double time, double value) {
    buffer.addPoint(time, value);
  }

  void _scheduleRetry() {
    if (_userStopped) return;
    if (_retryCount < maxRetries) {
      _retryCount++;
      _retryTimer?.cancel();
      _retryTimer = Timer(
        Duration(seconds: _retryCount * 2),
        _connectWebSocket,
      );
    }
  }

  @override
  void dispose() {
    channel?.sink.close();
    _retryTimer?.cancel();
    _missionTimer?.cancel();
    _animationController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  double _bufferValue(DashboardMetric metric) {
    switch (metric) {
      case DashboardMetric.altitude:
        return altitudeBuffer.hasData ? altitudeBuffer.buffer.last.value : 0.0;
      case DashboardMetric.speed:
        return speedBuffer.hasData ? speedBuffer.buffer.last.value : 0.0;
      case DashboardMetric.acceleration:
        return verticalAccBuffer.hasData
            ? verticalAccBuffer.buffer.last.value
            : 0.0;
      case DashboardMetric.orientation:
        return yawBuffer.hasData ? yawBuffer.buffer.last.value : 0.0;
      case DashboardMetric.environment:
        return temperatureBuffer.hasData
            ? temperatureBuffer.buffer.last.value
            : 0.0;
    }
  }

  Widget _buildDashboardPanel() {
    final items = _selectedMetrics;

    return Container(
      width: 280,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A).withOpacity(0.90),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.cyan.withOpacity(0.6), width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.cyan.withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              const Icon(Icons.dashboard, size: 18, color: Colors.white70),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'Tableau de bord',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    letterSpacing: 1,
                  ),
                ),
              ),
              TextButton(
                onPressed: _openDashboardEditor,
                child: const Text('Modifier'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: _dashboardCell(items[0])),
              const SizedBox(width: 10),
              Expanded(child: _dashboardCell(items[1])),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _dashboardCell(items[2])),
              const SizedBox(width: 10),
              Expanded(child: _dashboardCell(items[3])),
            ],
          ),
        ],
      ),
    );
  }

  Widget _dashboardCell(DashboardMetric metric) {
    return Container(
      height: 86,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF111827).withOpacity(0.96),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: metric.color.withOpacity(0.9), width: 2),
        boxShadow: [
          BoxShadow(color: metric.color.withOpacity(0.3), blurRadius: 12),
        ],
      ),
      child: Row(
        children: [
          Icon(metric.icon, color: metric.color, size: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  metric.label,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 6),
                Text(
                  _bufferValue(metric).toStringAsFixed(2),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _missionDurationBox() {
    String format(Duration d) {
      final h = d.inHours.toString().padLeft(2, '0');
      final m = (d.inMinutes % 60).toString().padLeft(2, '0');
      final s = (d.inSeconds % 60).toString().padLeft(2, '0');
      return '$h:$m:$s';
    }

    Widget _buildCounterCard(String label, int count, Color color) {
      return Expanded(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(label, style: TextStyle(fontSize: 14, color: Colors.white70)),
            SizedBox(height: 4),
            Text(
              '$count',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: color,
                shadows: [
                  Shadow(
                    color: Colors.black54,
                    offset: Offset(2, 2),
                    blurRadius: 4,
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      width: 265,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF2563EB), Color(0xFF7C3AED), Color(0xFF0F172A)],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white24, width: 1.0),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF7C3AED).withOpacity(0.35),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          const Icon(Icons.timer, color: Colors.white, size: 26),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Durée de mission',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Écoulé : ${format(_elapsedMission)}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _openDashboardEditor() {
    showDialog(
      context: context,
      builder: (dialogContext) {
        final tempSelected = List<DashboardMetric>.from(_selectedMetrics);

        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text('Modifier le tableau de bord'),
              content: SizedBox(
                width: 420,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: List.generate(4, (index) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: DropdownButtonFormField<DashboardMetric>(
                        value: tempSelected[index],
                        decoration: InputDecoration(
                          labelText: 'Case ${index + 1}',
                          border: const OutlineInputBorder(),
                        ),
                        items: DashboardMetric.values.map((metric) {
                          return DropdownMenuItem(
                            value: metric,
                            child: Text(metric.label),
                          );
                        }).toList(),
                        onChanged: (value) {
                          if (value == null) return;
                          setDialogState(() {
                            tempSelected[index] = value;
                          });
                        },
                      ),
                    );
                  }),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Annuler'),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _selectedMetrics
                        ..clear()
                        ..addAll(tempSelected);
                    });
                    Navigator.pop(dialogContext);
                  },
                  child: const Text('Valider'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: isDark
          ? const Color(0xFF0F172A)
          : const Color.fromARGB(255, 143, 138, 138),

      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.black, Colors.purple.withOpacity(0.3)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 20,
                offset: const Offset(0, 5),
              ),
            ],
          ),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isConnected ? Colors.greenAccent : Colors.redAccent,
                  width: 2,
                ),
              ),
              child: Icon(
                isConnected ? Icons.wifi : Icons.wifi_off,
                color: isConnected ? Colors.greenAccent : Colors.redAccent,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                isConnected ? 'Connecté au drone' : 'Reconnexion...',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.cyan,
          labelColor: Colors.cyan,
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(icon: Icon(Icons.trending_up), text: "Altitude"),
            Tab(icon: Icon(Icons.speed), text: "Vitesse"),
            Tab(icon: Icon(Icons.vibration), text: "Accélération"),
            Tab(icon: Icon(Icons.rotate_90_degrees_ccw), text: "Orientation"),
            Tab(icon: Icon(Icons.thermostat), text: "Environnement"),
          ],
        ),
      ),

      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.green.withOpacity(0.4),
                    Colors.cyan.withOpacity(0.5),
                    Colors.purple.withOpacity(0.4),
                    Colors.green.withOpacity(0.3),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Text(
                'Menu',
                style: TextStyle(
                  color: isDark ? Colors.white : Colors.black,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            ListTile(
              leading: Icon(
                Icons.timeline,
                color: isDark ? Colors.white : Colors.black,
              ),
              title: Text(
                'Graphique',
                style: TextStyle(color: isDark ? Colors.white : Colors.black),
              ),
              onTap: () {
                Navigator.pop(context);
              },
            ),

            ListTile(
              leading: Icon(
                Icons.history,
                color: isDark ? Colors.white : Colors.black,
              ),
              title: Text(
                'Historique',
                style: TextStyle(color: isDark ? Colors.white : Colors.black),
              ),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const HistoricalPage(),
                  ),
                );
              },
            ),

            ListTile(
              leading: Icon(
                Icons.brightness_6,
                color: isDark
                    ? const Color.fromARGB(255, 255, 255, 255)
                    : Colors.black,
              ),
              title: Text(
                isDark ? "Mode clair" : "Mode sombre",
                style: TextStyle(
                  color: isDark
                      ? const Color.fromARGB(255, 255, 255, 255)
                      : Colors.black,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  isDark = !isDark;
                });
              },
            ),
            ListTile(
              leading: Icon(
                Icons.refresh,
                color: isDark ? Colors.white : Colors.black,
              ),
              title: Text(
                'Reset ',
                style: TextStyle(color: isDark ? Colors.white : Colors.black),
              ),
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  missionCount = 0;
                  csvFilesCount = 0;
                });
              },
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          AnimatedBuilder(
            animation: _animationController,
            builder: (context, child) {
              return Padding(
                padding: const EdgeInsets.only(left: 280, top: 12),
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _buildChart(altitudeBuffer, "Altitude (m)", Colors.cyan),
                    _buildChart(speedBuffer, "Vitesse (m/s)", Colors.orange),
                    _buildChart(
                      verticalAccBuffer,
                      "Acc. Verticale (m/s²)",
                      Colors.purple,
                    ),
                    _buildOrientationChart(),
                    _buildSensorsChart(),
                  ],
                ),
              );
            },
          ),
          Positioned(
            top: 20,
            left: 24,
            child: Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildDashboardPanel(),
                  SizedBox(height: 12),
                  _missionDurationBox(),

                  Container(
                    margin: EdgeInsets.only(top: 20),

                    width: 265,
                    height: 120,
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.cyan.withOpacity(0.4),
                          Colors.purple.withOpacity(0.3),
                          Colors.green.withOpacity(0.2),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.cyanAccent, width: 3),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Missions',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              '$missionCount',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.cyan,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              ' CSV',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              '$csvFilesCount',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.cyan,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          Positioned(
            bottom: 0,
            left: 0,
            child: Container(
              width: 75,
              height: 60,
              child: Image.asset(
                'assets/images/Akatsuki.png',
                fit: BoxFit.cover,
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          if (isConnected) {
            endMission();
          } else {
            _resetForNewMission();
            missionCount++;
            _saveCounters();
          }
        },
        backgroundColor: isConnected ? Colors.red : Colors.green,
        child: Icon(isConnected ? Icons.stop : Icons.play_arrow),
      ),
    );
  }

  Widget _buildChart(CircularDataBuffer buffer, String title, Color color) {
    final data = buffer.visibleData;

    if (data.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: Colors.greenAccent),
            SizedBox(height: 16),
            Text(
              'En attente des données...',
              style: TextStyle(fontSize: 18, color: Colors.white70),
            ),
          ],
        ),
      );
    }

    final double maxTime = buffer.maxTime;
    final double minTime = maxTime - windowSize;

    final values = data.map((e) => e.value).toList();
    final minY = values.reduce(math.min) - 5;
    final maxY = values.reduce(math.max) + 5;
    final fixedMinY = ((minY / 5).floor() * 5).toDouble();
    final fixedMaxY = ((maxY / 5).ceil() * 5).toDouble();

    return Padding(
      padding: const EdgeInsets.all(8),
      child: SfCartesianChart(
        plotAreaBackgroundColor: const Color(0xFF0A0E17),
        plotAreaBorderWidth: 0,
        enableAxisAnimation: false,
        series: <SplineSeries<DataPoint, double>>[
          SplineSeries<DataPoint, double>(
            dataSource: data,
            width: 3.5,
            color: color,
            xValueMapper: (DataPoint d, _) => d.time,
            yValueMapper: (DataPoint d, _) => d.value,
            animationDuration: 0,
          ),
        ],
        primaryXAxis: NumericAxis(
          minimum: minTime,
          maximum: maxTime,
          interval: 1,
          axisLabelFormatter: (AxisLabelRenderDetails details) {
            final seconds = details.value?.toInt() ?? 0;
            final minutes = (seconds ~/ 60).toString().padLeft(2, '0');
            final secs = (seconds % 60).toString().padLeft(2, '0');
            return ChartAxisLabel(
              '$minutes:$secs',
              const TextStyle(color: Colors.white70, fontSize: 12),
            );
          },
          majorGridLines: const MajorGridLines(
            color: Color(0xFF1A3C34),
            width: 1,
            dashArray: [5, 5],
          ),
          axisLine: const AxisLine(color: Color(0xFF2D5A4A), width: 1.5),
        ),
        primaryYAxis: NumericAxis(
          minimum: fixedMinY,
          maximum: fixedMaxY,
          interval: 5,
          labelFormat: '{value}',
          majorGridLines: const MajorGridLines(color: Colors.white12),
          axisLine: const AxisLine(width: 0),
          labelStyle: const TextStyle(color: Colors.white70),
          rangePadding: ChartRangePadding.none,
        ),
        title: ChartTitle(
          text: title,
          textStyle: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildOrientationChart() {
    final rollData = rollBuffer.visibleData;
    final pitchData = pitchBuffer.visibleData;
    final yawData = yawBuffer.visibleData;

    if (rollData.isEmpty && pitchData.isEmpty && yawData.isEmpty) {
      return const Center(
        child: Text(
          'En attente orientation...',
          style: TextStyle(fontSize: 18, color: Colors.white70),
        ),
      );
    }

    final times = [
      rollBuffer.hasData ? rollBuffer.maxTime : double.negativeInfinity,
      pitchBuffer.hasData ? pitchBuffer.maxTime : double.negativeInfinity,
      yawBuffer.hasData ? yawBuffer.maxTime : double.negativeInfinity,
    ];
    final maxTime = times.reduce(math.max);
    final minTime = maxTime - windowSize;

    return Padding(
      padding: const EdgeInsets.all(8),
      child: SfCartesianChart(
        plotAreaBackgroundColor: const Color(0xFF0A0E17),
        plotAreaBorderWidth: 0,
        enableAxisAnimation: false,
        legend: const Legend(
          isVisible: true,
          position: LegendPosition.bottom,
          height: '20%',
          textStyle: TextStyle(color: Colors.white70, fontSize: 12),
        ),
        primaryXAxis: NumericAxis(
          minimum: minTime,
          maximum: maxTime,
          interval: 1,
          axisLabelFormatter: (AxisLabelRenderDetails details) {
            final seconds = details.value?.toInt() ?? 0;
            final minutes = (seconds ~/ 60).toString().padLeft(2, '0');
            final secs = (seconds % 60).toString().padLeft(2, '0');
            return ChartAxisLabel(
              '$minutes:$secs',
              const TextStyle(color: Colors.white70, fontSize: 12),
            );
          },
          majorGridLines: const MajorGridLines(color: Color(0xFF1A3C34)),
          axisLine: const AxisLine(color: Color(0xFF2D5A4A)),
        ),
        primaryYAxis: const NumericAxis(
          labelFormat: '{value}°',
          majorGridLines: MajorGridLines(color: Colors.white12),
        ),
        title: const ChartTitle(
          text: "Orientation (Roll/Pitch/Yaw)",
          textStyle: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        series: <SplineSeries<DataPoint, double>>[
          SplineSeries<DataPoint, double>(
            dataSource: rollData,
            color: Colors.red,
            width: 2.8,
            xValueMapper: (DataPoint d, _) => d.time,
            yValueMapper: (DataPoint d, _) => d.value,
            name: 'Roll',
            animationDuration: 0,
          ),
          SplineSeries<DataPoint, double>(
            dataSource: pitchData,
            color: Colors.greenAccent,
            width: 2.8,
            xValueMapper: (DataPoint d, _) => d.time,
            yValueMapper: (DataPoint d, _) => d.value,
            name: 'Pitch',
            animationDuration: 0,
          ),
          SplineSeries<DataPoint, double>(
            dataSource: yawData,
            color: Colors.blueAccent,
            width: 2.8,
            xValueMapper: (DataPoint d, _) => d.time,
            yValueMapper: (DataPoint d, _) => d.value,
            name: 'Yaw',
            animationDuration: 0,
          ),
        ],
      ),
    );
  }

  Widget _buildSensorsChart() {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          Expanded(
            child: _buildChart(pressureBuffer, "Pression (hPa)", Colors.indigo),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: _buildChart(
              temperatureBuffer,
              "Température (°C)",
              Colors.amber,
            ),
          ),
        ],
      ),
    );
  }
}
