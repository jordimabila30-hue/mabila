package com.example.application_faustin

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
